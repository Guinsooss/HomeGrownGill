menu = {
    'fruits': {
        'apples': {
            'price': 3
        },
        'oranges': {
            'price': 3
        },
        'watermelon': {
            'price': 1.50
        }
    },

    'vegetables': {
        'potato': {
            'price': 1
        },
        'cabbage':{
            'price' : 2.50
        },
        'carrot': {
            'price': 1.50
        },
    },

    'milk_products': {
        'milk': {
            'price': 2.00
        },

    },

    'nuts:': {
        'peanuts:': {
            'price:': 2.50
        },
        'almond:': {
            'price:': 2.50
        },
        'pistachio': {
            'price': 2.50
        }
    },
    'jams': {
        'raspberry': {
            'price': 4
        },
        'blackberry': {
            'price': 4
        },

    },

    'juices':{
        'apple': {
            'price': 3
        },
        'orange': {
            'price': 4
        }
    }
}

# print(menu)
