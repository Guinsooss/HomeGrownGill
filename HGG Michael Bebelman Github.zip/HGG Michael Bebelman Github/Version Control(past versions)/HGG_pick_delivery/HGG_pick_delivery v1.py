def pickup_delivery():
    del_pick = True
    while del_pick:
        option = input("Would you like your order to be delivered or ready for pickup (Delivery is $3 Extra)? ").lower()
        if option == "delivery" or option == "d":
            delivery_address = input("What is your delivery address? ")
            correct = input("Is this the correct address, {} (Yes or No)? ".format(delivery_address)).lower()



