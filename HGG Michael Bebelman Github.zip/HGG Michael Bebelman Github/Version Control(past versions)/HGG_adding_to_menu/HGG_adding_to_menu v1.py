menu = {
    'fruit': {
        'apples': {
            'price': 3
        },
        'oranges': {
            'price': 3
        },
        'watermelon': {
            'price': 1.50
        }
    },

    'vegetables': {
        'potato': {
            'price': 1
        },
        'cabbage':{
            'price' : 2.50
        },
        'carrot': {
            'price': 1.50
        },
    },

    'dairy': {
        'milk': {
            'price': 2.00
        },

    },

    'nuts:': {
        'peanuts:': {
            'price:': 2.50
        },
        'almond:': {
            'price:': 2.50
        },
        'pistachio': {
            'price': 2.50
        }
    },
    'jams': {
        'raspberry': {
            'price': 4
        },
        'blackberry': {
            'price': 4
        },

    },

    'juice':{
        'apple': {
            'price': 3
        },
        'orange': {
            'price': 4
        }
    }
}

# print(menu)


def add(dict, amount):
    try:
        try:
            item_type = input("What item type would you like to add (fruits, vegetables, dairy, nuts, jams, juices")
            item = input("What item would you like to add? ")
            cost = int(input("What price would you like this item to cost? "))
            dict[item_type][item] = {amount:cost}
        except KeyError:
            print("Please select a correct item type. ")
    except ValueError:
        print("Please enter a price with numerical values and above $0. ")

    print(menu)

add()

