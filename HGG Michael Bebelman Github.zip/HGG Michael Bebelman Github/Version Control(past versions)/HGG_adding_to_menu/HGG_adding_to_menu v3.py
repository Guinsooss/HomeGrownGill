menu = {
    'fruits': {
        'apples': {
            'price': 3
        },
        'oranges': {
            'price': 3
        },
        'watermelon': {
            'price': 1.50
        }
    },

    'vegetables': {
        'potato': {
            'price': 1
        },
        'cabbage':{
            'price' : 2.50
        },
        'carrot': {
            'price': 1.50
        },
    },

    'dairy': {
        'milk': {
            'price': 2.00
        },

    },

    'nuts': {
        'peanuts:': {
            'price:': 2.50
        },
        'almond:': {
            'price:': 2.50
        },
        'pistachio': {
            'price': 2.50
        }
    },
    'jams': {
        'raspberry': {
            'price': 4
        },
        'blackberry': {
            'price': 4
        },

    },

    'juices': {
        'apple': {
            'price': 3
        },
        'orange': {
            'price': 4
        }
    }
}

# print(menu)


def add(dict, amount):
    loop = True
    while loop:
        try:
            try:
                item_type = input('What item type would you like to add (fruits, vegetables, dairy, nuts, jams, juices)? ').lower()
                item = input('What item would you like to add? ').lower()
                cost = str(input('What price would you like {} to cost? '.format(item)))
                cost = float(cost)
                dict[item_type][item] = {amount:cost}
                loop = False
                print('{} has been added for ${}'.format(item.capitalize(), cost))
            except KeyError:
                print('Please select a correct item type. ')
        except ValueError:
            print('Please enter a price with numerical values and above $0. ')


add(menu,'price')

loop = True
while loop:
    repeat = input("Would you like to add another item? (Yes or no) ").lower()
    if repeat == "yes":
        add(menu, 'price')
    else:
        loop = False


print('The new menu is: ')
for key, menu in menu.items():
    print()
    print(key.capitalize())
    print()
    for attribute, value in menu.items():
        print('{} : {}'.format(attribute.capitalize(), value))
