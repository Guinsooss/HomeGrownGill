# Creating function for customer details
def customer_details():
    name = str(input("What is your name? "))
    address = input("What is your home address? ")
    while True:
        try:
            phone_number = int(input("What is your phone number "))
            # if not a positive int print message and ask for input again
            if phone_number < 0:
                print("Sorry, this is not a phone number")
                continue
            break
        except ValueError:
            print("A phone number is only numbers, please input a valid phone number.")
            continue
        else:
            break
    print("")
    print("")
    print("The name you have entered is {}".format(name))
    print("The address you have entered is {}".format(address))
    print("The phone number you have entered is {}".format(phone_number))


customer_details()




