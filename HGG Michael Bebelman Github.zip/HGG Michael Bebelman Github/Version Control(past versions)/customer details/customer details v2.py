# Creating function for customer details
def customer_details():
    phone_num = True
    name = str(input("What is your name? "))
    address = input("What is your home address? ")
    while phone_num:
        phone_number = str(input("What is your phone number "))
        try:
            if int(phone_number) <0:
                print("A phone number needs to have numerical values above 0. ")
                continue
            else:
                phone_num = False

        except ValueError:
            print("Please enter a valid phone number. ")


    return name, address, phone_number


name, address, phone_number = customer_details()
print(name, address, phone_number)



