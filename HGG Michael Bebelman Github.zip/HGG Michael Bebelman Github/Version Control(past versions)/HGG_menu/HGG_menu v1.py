menu = {
    'fruit:' : {
        'apples:': {
            'price:': 3
        },
        'oranges:': {
            'price:': 3
        },
        'watermelon:': {
            'price:': 1.50
        }
    },
    'vegetables:': {
        ''

    }

}