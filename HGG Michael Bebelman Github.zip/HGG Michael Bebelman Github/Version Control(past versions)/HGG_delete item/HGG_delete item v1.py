order = {'apples': {'price for each item': 3, 'quantity': 20}, 'oranges': {'price for each item': 3, 'quantity': 2}, 'watermelon': {'price for each item': 1.5, 'quantity': 2}, 'potato': {'price for each item': 1, 'quantity': 2}, 'raspberry jam': {'price for each item': 4, 'quantity': 2}, 'apple juice': {'price for each item': 3, 'quantity': 5}}



def delete(order_dict):
    delete = True
    while delete:
        try:
            try:
                order_item = input("What item would you like to delete from your order? ").lower()
                order_del_quantity = int(input("How many would you like to delete off of your order? "))
               # print("printing",menu_dict.items())
                if order_del_quantity <= 0:
                    print("Please enter a number larger than 0. ")
                else:
                    if order_item in order_dict:
                        order_dict[order_item]['quantity'] = order_dict[order_item]['quantity'] - order_del_quantity
                        # print("hi")
                        delete = False
                    if order_dict[order_item]['quantity'] - order_del_quantity == 0 or order_dict[order_item]['quantity'] - order_del_quantity < 0:
                        order_dict.pop(order_item)
                        # print("asdfsda")
            except KeyError:
                print("Please enter in a correct item. ")
        except ValueError:
            print("Please enter in a quantity above 0 and a whole number. ")

    print("{} {} have been removed from your order.".format(order_del_quantity, order_item))
    print()
    print("Your new order is:")
    for attribute, value in order.items():
        print(attribute.capitalize())
        print("Quantity: {}".format(value['quantity']))
        print()


delete(order)

delete_loop = True
while delete_loop:
    answer = input("Would you like to delete another item.").lower()
    if answer == "yes":
        delete(order)
    elif answer == "no":
        delete_loop = False
    else:
        print("Print please enter yes or no")


