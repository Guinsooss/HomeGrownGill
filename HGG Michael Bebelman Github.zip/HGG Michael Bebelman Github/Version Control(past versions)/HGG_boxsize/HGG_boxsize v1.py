order = {'apples': {'price for each item': 3, 'quantity': 20}, 'oranges': {'price for each item': 3, 'quantity': 2}, 'watermelon': {'price for each item': 1.5, 'quantity': 2}, 'potato': {'price for each item': 1, 'quantity': 2}, 'raspberry jam': {'price for each item': 4, 'quantity': 2}, 'apple juice': {'price for each item': 3, 'quantity': 5}}

def box(order_dict):
    total_quantity = 0
    for order_item in order_dict:
        total_quantity1 = order_dict[order_item]['quantity']
        total_quantity = total_quantity + total_quantity1
    print()
    print('Total pice for all of your items is ${}'.format(total_quantity))


box(order)