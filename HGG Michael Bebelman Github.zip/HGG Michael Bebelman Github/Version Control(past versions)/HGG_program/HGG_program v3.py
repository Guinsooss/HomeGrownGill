import math


menu = {
    # item categories
    'fruits': {
        # items inside each category
        'apples': {
            # the price of the item
            'price': 3
        },
        'oranges': {
            'price': 3
        },
        'watermelon': {
            'price': 1.50
        }
    },

    'vegetables': {
        'potato': {
            'price': 1
        },
        'cabbage': {
            'price': 2.50
        },
        'carrot': {
            'price': 1.50
        },
    },

    'dairy': {
        'milk': {
            'price': 2.00
        },

    },

    'nuts': {
        'peanuts': {
            'price': 2.50
        },
        'almond:': {
            'price': 2.50
        },
        'pistachio': {
            'price': 2.50
        }
    },
    'jams': {
        'raspberry': {
            'price': 4
        },
        'blackberry': {
            'price': 4
        },

    },

    'juices': {
        'apple juice': {
            'price': 3
        },
        'orange juice': {
            'price': 4
        }
    }
}


order = {

}


def customer_details():
    # phone_num is for loop within function
    phone_num = True
    # asking for name
    name_input = str(input("What is your name? "))
    # asking for address
    address_input = input("What is your home address? ")
    while phone_num:
        # asking for a phone number that is a string
        phone_number_input = str(input("What is your phone number "))
        try:
            # checking and converting the string into a integer that is above 0
            if int(phone_number_input) < 0:
                print("A phone number needs to have numerical values above 0. ")
                continue
            else:
                # ending loop if phone number is greater than 0
                phone_num = False
                return name_input, address_input, phone_number_input

        except ValueError:
            # printing an error
            print("Please enter a valid phone number. ")


# creating a function for the questions
def add(dictionary, amount):
    # creating the loop
    loop = True
    while loop:
        try:
            try:
                # asking which item type the item will go under
                item_type = input('What item type would you like to add (fruits, vegetables, dairy, nuts,'
                                  ' jams, juices)? ').lower()
                # asking what the item will be
                item = input('What item would you like to add? ').lower()
                # asking what the item's price will be
                cost = str(input('What price would you like {} to cost? '.format(item)))
                # converting the cost into a float
                cost = float(cost)
                # adding the item and its cost to the dictionary
                dictionary[item_type][item] = {amount: cost}
                loop = False
                print('{} has been added for ${}'.format(item.capitalize(), cost))
                # validation if the key is incorrect
            except KeyError:
                print('Please select a correct item type. ')
        # making sure that the price is a number
        except ValueError:
            print('Please enter a price with numerical values and above $0. ')


# creating the ordering system
def ordering(menu_dict, order_dict):
    # creating ordering loop
    order_loop = True
    while order_loop:
        try:
            try:
                # asking them which item they would like to purchase
                order_item = input("What item would you like to purchase from the menu? ").lower()
                # asking how many items they would like to purchase
                order_quantity = int(input("How many would you like to purchase? "))
                # print("printing",menu_dict.items())
                # if the item is already in the order
                if order_item in order_dict:
                    # add the quantity in the above statement to the quantity already in the order
                    order_dict[order_item]['quantity'] = order_dict[order_item]['quantity'] + order_quantity
                    # print("hi")
                    # break the loop
                    break
                else:
                    for category, value in menu_dict.items():
                        # print("sd",category)
                        # print("fh",value)
                        #  print("printing",list(value.keys()))
                        # if the order item is is in the dictionary
                        if order_item in list(value.keys()):
                            # print("hello")
                            # add the order item and quantity to the empty dictionary
                            order_dict[order_item] = {'price for each item': value[order_item]['price'], 'quantity': order_quantity}
                            order_loop = False
                            break
                # if the item is not in the menu
                if order_item not in order_dict:
                    # print error message
                    print("Please enter in a correct item. ")
            except KeyError:
                print("Please enter in a correct item. ")
        except ValueError:
            print("Please enter in a quantity above 0 and a whole number. ")


def total_cost(order_dict):
    # set the price to 0
    price = 0
    print("Your order is:")
    print()
    # for all items in the order dictionary
    for order_item in order_dict:
        # sets up total cost
        price2 = price
        # calculating the price per item
        price = (order_dict[order_item]['quantity'] * order_dict[order_item]['price for each item'])
        print(order_item.capitalize())
        # printing out the individual total item price

        print('Total item price is ${}'.format(price))
        print()
        # add the total individual item prices together
        price = price + price2
    print()
    # printing out total price
    print('Total price for all of your items is ${}'.format(price))
    return price


# creating delete item function
def delete(order_dict):
    # creating a loop
    del_loop = True
    while delete:
        try:
            try:
                # asking what item they would like to delete / remove quantity
                order_item = input("What item would you like to delete/ lower the quantity of from "
                                   "your order? ").lower()
                # asking the quantity of the items they would like to remove
                order_del_quantity = int(input("How many would you like to delete off of your order? "))
                # print("printing",menu_dict.items())
                # if the quantity to remove is larger than the quantity available to be removed
                if order_del_quantity <= 0:
                    print("Please enter a number larger than 0. ")
                else:
                    # if the item is in the order
                    if order_item in order_dict:
                        # remove the quantity
                        order_dict[order_item]['quantity'] = order_dict[order_item]['quantity'] - order_del_quantity
                        # print("hi")
                        # stop the loop
                        del_loop = False
                        break
                    # if the quantity goes below 0 or at 0
                    elif order_dict[order_item]['quantity'] - order_del_quantity == 0 or order_dict[order_item]['quantity'] - order_del_quantity < 0:
                        # remove from the order
                        # order_dict.pop(order_item)
                        print("asdfsda")
            except KeyError:
                print("Please enter in a correct item. ")
        except ValueError:
            print("Please enter in a quantity above 0 and a whole number. ")
    # print out messages saying the amount deleted and what item it was from
    print("{} {} have been removed from your order.".format(order_del_quantity, order_item))
    print()
    # re-printing order
    print("Your new order is:")
    for attribute, value in order.items():
        print(attribute.capitalize())
        print("Quantity: {}".format(value['quantity']))
        print()


# creating box size function
def box(order_dict, price):
    # setting the quantity to 0
    total_quantity = 0
    # for the items and quantities in your order
    for order_item in order_dict:
        # add the total quantity together
        total_quantity1 = order_dict[order_item]['quantity']
        total_quantity = total_quantity + total_quantity1
    print()
    # print out how many items are in your order
    print("You have {} item(s) in your cart.".format(total_quantity))
    # ask if they want paper bags or boxes
    paper_bags = input("Would you like to use paper bags ($1 extra) or different boxes? ").lower()
    # checking the input
    if paper_bags == "yes" or paper_bags == "p" or paper_bags == "paper" or paper_bags == "paper bags" \
            or paper_bags == "bags":
        print("Your order will be packaged in paper bags.")
        bag_price = price + 1
        return bag_price
    else:
        # if the total quantity is less than 10
        if total_quantity < 10:
            # divide by 5
            box_amount = total_quantity / 5
            # round the number up
            box_amount = math.ceil(box_amount)
            print("{} small box(s) will store all your items.".format(box_amount))
        # if the total quantity is greater than 10 but less than 30
        elif 10 < total_quantity < 30:
            # divide by 10
            box_amount = total_quantity / 10
            # round the number up
            box_amount = math.ceil(box_amount)
            print("{} medium box(s) will store all your items.".format(box_amount))
        # if the quantity is above 30
        elif total_quantity > 30:
            # divide by 15
            box_amount = total_quantity / 15
            # round the number up
            box_amount = math.ceil(box_amount)
            print("{} large box(s) will store all your items.".format(box_amount))
        return price


def print_dict(dictionary):
    print()
    print('The new menu is: ')
    for key, dictionary in dictionary.items():
        print()
        print(key.capitalize())
        print()
        for attribute, value in dictionary.items():
            print('{} : ${}'.format(attribute.capitalize(), value['price']))


def pickup_delivery(price):
    # loop for repeating question if needed
    del_pick = True
    while del_pick:
        # asking the user if they want delivery or pick up
        option = input("Would you like your order to be delivered or ready for pickup (Delivery is $3 Extra)? ").lower()
        # if they pick delivery
        if option == "delivery" or option == "d":
            # ask for delivery address
            delivery_address = input("What is your delivery address? ")
            # ask if the input delivery was correct
            correct = input("Is this the correct address, {} (Yes or No)? ".format(delivery_address)).lower()
            # if it is correct
            if correct == "yes":
                # print the delivery address
                print("Your order will be sent to {} within 2-3 working days.".format(delivery_address))
                new_price = price + 3
                return new_price

            else:
                print("Please input yes or no. ")
        # if the user picked pick up
        if option == "pick up" or option == "pickup" or option == "p":
            # tell them when it will be ready to pick up
            print("We will call you on {} when your order is ready to pick up. ".format(phone_number))
            # making it so the loop does not continue
            del_pick = False
            return price


name, address, phone_number = customer_details()

print("Welcome {} to Home Grown Gill's store!".format(name.title()))

over_all_loop = True
while over_all_loop:
    print()
    option = input('''
    1. Add an item to the menu
    2. Add an item to your order
    3. View the Total cost of your order
    4. Delete or lower the quantity of an item from your order
    5. Complete your order and chose Delivery/pick up options
    6. Cancel order
    
    Please enter in 1,2,3,4,5 or 6. ''')

    if option == "1":
        # setting up a loop
        repeat_loop = True
        while repeat_loop:
            add(menu, 'price')
            # asking if they want to repeat the function
            repeat = input("Would you like to add another item to the menu? (Yes or no) ").lower()
            if repeat == "yes":
                add(menu, 'price')
            elif repeat == "no":
                repeat_loop = False
            else:
                # stopping the loop
                print("Please enter yes or no. ")
        print_dict(menu)

    elif option == "2":
        print_dict(menu)
        ordering(menu, order)

        # repeat ordering loop
        repeat_order = True
        while repeat_order:
            # asking if they want to repeat their order
            r_order = input("Would you like to add another item to your order? (Yes or no) ").lower()
            # if yes
            if r_order == "yes":
                # redo ordering function
                ordering(menu, order)
            # if no
            elif r_order == "no":
                # break the loop
                repeat_order = False
            # if input was not yes or no
            else:
                # ask them to redo
                print("Please enter yes or no.")

        # for key, order in order.items():
        print()
        print("Your order is:")
        # print(key.capitalize())
        for attribute, value in order.items():
            # print item
            print(attribute.capitalize())
            # print the individual price for the items
            print("Price per item: ${}".format(value['price for each item']))
            # print the quantity they selected
            print("Quantity: {}".format(value['quantity']))
            print()

    elif option == "3":
        # calls the total_cost function
        total_cost(order)

    elif option == "4":
        # ask the user if they are sure about deleting an item
        option = input("Would you like to delete an item off of your order? ")
        # if answer is yes
        if option == 'yes':
            # call the delete function
            delete(order)
            # creating a loop for the delete function
            delete_loop = True
            while delete_loop:
                print()
                # ask if they want to delete another item
                answer = input("Would you like to delete another item.").lower()
                print()
                # if answer is yes
                if answer == "yes":
                    # call teh delete function again
                    delete(order)
                # if answer is no
                elif answer == "no":
                    # make the loop equal to false
                    delete_loop = False
                else:
                    # ask the user to enter yes or no
                    print("Print please enter yes or no")
        elif option == "no":
            continue

    if option == "5":
        print()
        order_price = total_cost(order)
        box_price = box(order, order_price)
        final_price = pickup_delivery(box_price)
        print('The total cost of your order is ${}. '.format(final_price))
        over_all_loop = False
        print("Thanks for shopping at Home Grown Gill's, please come again another time.")

    if option == "6":
        cancel = input("Are you sure you would like to cancel your order? ")
        cancel_loop = True
        while cancel_loop:
            if cancel == "yes" or cancel == "y":
                cancel_loop = False
                break
            elif cancel == "no" or cancel == "n":
                continue
                cancel_loop = False
        if cancel == "yes" or cancel == "y":
            break
    # else:
        # print("Please enter in a correct option.")