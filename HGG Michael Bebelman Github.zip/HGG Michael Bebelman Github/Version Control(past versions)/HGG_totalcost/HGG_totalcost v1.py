order = {'apples': {'price for each item': 3, 'quantity': 20}, 'oranges': {'price for each item': 3, 'quantity': 2}, 'watermelon': {'price for each item': 1.5, 'quantity': 2}, 'potato': {'price for each item': 1, 'quantity': 2}, 'raspberry jam': {'price for each item': 4, 'quantity': 2}, 'apple juice': {'price for each item': 3, 'quantity': 5}}

def total_cost(order_dict):
    price = 0
    for order_item in order_dict:
        price2 = price
        price = (order_dict[order_item]['quantity'] * order_dict[order_item]['price for each item'])
        print(order_item.capitalize())
        print('Total item price is ${}'.format(price))
        print()
        price = price + price2
    print()
    print('Total pice for all of your items is ${}'.format(price))



total_cost(order)